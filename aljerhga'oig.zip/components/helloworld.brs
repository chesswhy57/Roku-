
function init()
    menuonfoucs=true
    m.top.setFocus(true)
    m.myLabel = m.top.findNode("myLabel")
    m.myStartButton = m.top.findNode("nicebutton")
    m.myResignButton = m.top.findNode("resignbutton")
    m.myStartButton.setFocus(true)
    m.myLabel.font.size=150
    m.myLabel.color="0x72D7EEFF"
    menuonfoucs=true
    for h = 0 to 7
        for i = 0 to 7

            myRectangle = CreateObject("roSGNode", "Rectangle")
            myRectangle.width = 80
            myRectangle.height = 80
            myRectangle.id = "rect" + h.toStr() + i.toStr()
            if i MOD 2 = h MOD 2 then
                myRectangle.color = "0xFFFFFFFF"
            else
                myRectangle.color = "0x000000FF"
            end if
         myRectangle.translation = [i*80+40, h*80+40]
        m.top.appendChild(myRectangle)
         end for
    end for
end function
function onKeyEvent(key as String, press as Boolean) as Boolean
    if press and key="down" and m.global.menuonfoucs then
        m.myResignButton.setFocus(true)
    end if
    if press and key="up" then
        m.myStartButton.setFocus(true)
    end if
end function 
